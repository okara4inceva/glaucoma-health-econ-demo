# Glaucoma Health Economics Demo

**Rapid portfolio project for an ophthalmology research / health economics interview**

This repository demonstrates a simple health economic evaluation of an **early glaucoma detection pathway** compared with usual opportunistic detection in an ophthalmology setting.

> **Important:** This is a demo project. The dataset is fully simulated and does not contain real patient data.

## Why glaucoma?

Glaucoma is a chronic progressive eye disease that can cause irreversible vision loss. From a health economics perspective, the key question is whether earlier detection can reduce later disease burden, avoid advanced-stage management costs, and support more efficient ophthalmology service planning.

This demo links:
- ophthalmology clinical pathway thinking,
- simulated patient-level data,
- cost-consequence analysis,
- one-year budget impact,
- simple sensitivity analysis,
- implementation plan for real-world EHR data.

## Research question

> What is the potential economic value of structured early glaucoma detection compared with usual care in an ophthalmology clinic?

## Methods

Two pathways are compared:

| Pathway | Description |
|---|---|
| Usual care | Glaucoma is detected opportunistically or later in the pathway |
| Early detection | High-risk adults receive structured case-finding / screening using ophthalmology tests |

The model estimates:

- expected glaucoma cases,
- detected cases under each pathway,
- additional early cases detected,
- advanced cases avoided,
- direct budget impact,
- productivity loss avoided,
- net societal budget impact,
- cost per additional early case detected.

## Base-case assumptions

| Input | Value |
|---|---:|
| Target population screened | 1,000 |
| Screening cost per person | 250 AED |
| Glaucoma prevalence in high-risk group | 5% |
| Usual care detection rate | 40% |
| Early detection rate | 80% |
| Progression to advanced disease, usual care | 25% |
| Progression to advanced disease, early detection | 10% |
| Annual early glaucoma management cost | 1,500 AED |
| Annual advanced glaucoma management cost | 6,000 AED |

All values are illustrative and should be replaced with UAE hospital tariff, payer, EHR, pharmacy, and clinician-validated estimates in a real study.

## Base-case results

| Result | Value |
|---|---:|
| Expected glaucoma cases | 50 |
| Detected cases with usual care | 20 |
| Detected cases with early detection | 40 |
| Additional early cases detected | 20 |
| Advanced cases avoided | 7.5 |
| Screening program cost | 250,000 AED |
| Incremental direct budget impact | 216,250 AED |
| Productivity loss avoided | 52,500 AED |
| Net societal budget impact | 163,750 AED |
| Cost per additional early case detected | 12,500 AED |

## Repository structure

```text
glaucoma-health-econ-demo/
├── data/
│   ├── glaucoma_demo_patients.csv
│   └── data_dictionary.md
├── docs/
│   ├── methods.md
│   ├── crf_template.md
│   ├── future_real_world_data_plan.md
│   └── interview_pitch.md
├── notebooks/
│   └── glaucoma_health_econ_demo.ipynb
├── outputs/
│   ├── base_case_results.csv
│   ├── sensitivity_one_way.csv
│   ├── model_summary.txt
│   └── charts/
├── src/
│   ├── generate_demo_data.py
│   ├── run_model.py
│   └── sensitivity_analysis.py
├── requirements.txt
├── .gitignore
└── README.md
```

## How to run

```bash
pip install -r requirements.txt
python src/generate_demo_data.py
python src/run_model.py
python src/sensitivity_analysis.py
```

## Outputs

The project generates:

- `data/glaucoma_demo_patients.csv`
- `outputs/base_case_results.csv`
- `outputs/sensitivity_one_way.csv`
- `outputs/charts/detection_comparison.png`
- `outputs/charts/budget_impact.png`
- `outputs/charts/sensitivity_tornado.png`

## Data sources for real-world version

In a real hospital study, data would come from:

| Source | Data elements |
|---|---|
| Epic / EHR | demographics, diagnosis, visits, comorbidities |
| Ophthalmology records | glaucoma stage, clinical notes, management plan |
| OCT system | RNFL thickness, optic nerve assessment |
| Visual field system | visual field defect severity |
| Pharmacy | glaucoma medication use and cost |
| Billing / finance | consultation, test, procedure, and surgery costs |
| Patient questionnaires | quality of life, productivity loss, caregiver impact |

Real-world use would require IRB/ethics approval, data access approval, de-identification, and clinician validation.

## References

- WHO. Blindness and vision impairment fact sheet. https://www.who.int/news-room/fact-sheets/detail/blindness-and-visual-impairment
- IAPB Vision Atlas. United Arab Emirates country data. https://visionatlas.iapb.org/country-data/united-arab-emirates/
- NICE guideline NG81. Glaucoma: diagnosis and management. https://www.nice.org.uk/guidance/ng81
- Burton MJ et al. The Lancet Global Health Commission on Global Eye Health. https://www.thelancet.com/journals/langlo/article/PIIS2214-109X(20)30488-5/fulltext

## Suggested CV bullet

> Developed a rapid health economics demo evaluating early glaucoma detection in an ophthalmology setting using simulated patient-level data, cost-consequence analysis, budget impact modelling, and one-way sensitivity analysis. Designed a real-world data collection plan linking EHR, OCT, visual field, pharmacy, billing, and patient-reported outcomes.
