# Interview Pitch

## 30-second version

I created a rapid health economics demo for early glaucoma detection in an ophthalmology clinic. The project compares usual care with a structured early detection pathway using simulated patient-level data. It estimates additional early cases detected, advanced cases avoided, direct budget impact, productivity loss avoided, and one-way sensitivity analysis. The purpose is not to claim clinical effectiveness, but to show how I would support clinicians with research design, data structure, cost analysis, and decision-focused outputs.

## 60-second version

For this demo, I focused on glaucoma because it is a chronic progressive disease where late diagnosis can lead to irreversible vision loss and higher long-term burden. I built a simple cost-consequence and budget impact model comparing usual care with structured early detection. The repository includes simulated patient data, a data dictionary, a CRF template, Python scripts, results tables, charts, and a real-world data collection plan.

In a real hospital setting, I would replace the assumptions with de-identified data from Epic/EHR, OCT and visual field systems, pharmacy, billing, and patient-reported outcomes after IRB approval. This project shows how I can connect clinical research operations with health economics, data analytics, and manuscript-ready research outputs.

## How to connect it to the Research Scholar role

This project demonstrates my ability to:

- review clinical and economic evidence,
- create structured research datasets,
- prepare CRF-style variables,
- support clinicians with study design,
- clean and validate patient-level data,
- create research outputs suitable for abstracts, reports, or manuscripts,
- translate clinical questions into measurable economic outcomes.

## What I would say if they ask: “Why simulated data?”

I used simulated data because this is a safe portfolio demo. It avoids any patient privacy risk. In a real research project, I would only use de-identified hospital data after ethics approval, data governance clearance, and clinician validation of variables.

## What I would say if they ask: “Where would real data come from?”

Real data would come from Epic/EHR for demographics, diagnosis, visits, and comorbidities; ophthalmology diagnostic systems for OCT and visual field results; pharmacy systems for glaucoma medications; billing systems for costs; and patient questionnaires for quality of life and productivity impact.

## What I would say if they ask: “What is the health economics value?”

The value is that the model does not only ask whether early detection finds more cases. It asks whether earlier detection may change resource use, reduce advanced disease burden, and support better service planning from a hospital or payer perspective.
